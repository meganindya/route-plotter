import cv2
import numpy as np
import matplotlib.pyplot as plt
import networkx as nx
from PIL import Image
from skimage.morphology import skeletonize
from skimage.util import invert
import sknw


img = cv2.imread("dpixel.jpg")
img = invert(img)
grayscaled = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)

    #BınaryThreshold + OtsuThreshold + BinaryThreshold
retval, threshold = cv2.threshold(grayscaled, 10, 255, cv2.THRESH_BINARY_INV+cv2.THRESH_OTSU)
retval, threshold2 = cv2.threshold(threshold, 10, 255, cv2.THRESH_BINARY_INV)
threshold2[threshold2 == 255] = 1

    #Skeletonize the Thresholded Image
skel = skeletonize(threshold2)

    #Build Graph from skeleton
graph = sknw.build_sknw(skel, multi=False)
G = nx.Graph(graph)
plt.imshow(img, cmap='gray')

    #Draw Edges by 'pts'
for (s,e) in graph.edges():
    ps = graph[s][e]['pts']
    plt.plot(ps[:,1], ps[:,0], 'red')

    #Draw Node by 'o'   
node, nodes = graph.node, graph.nodes()
ps = np.array([node[i]['o'] for i in nodes])
plt.plot(ps[:,1], ps[:,0], 'g.')
plt.title('Skeletonize')
#plt.savefig('Overlay_Maze.jpg')
plt.show()

G = nx.path_graph(len(ps))
G = nx.karate_club_graph()
pos = nx.spring_layout(G)
nx.draw(G,pos,node_color='b')
