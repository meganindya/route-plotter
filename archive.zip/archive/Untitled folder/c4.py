import cv2
import numpy as np
import matplotlib.pyplot as plt
import networkx as nx
from queue import PriorityQueue
import pickle

G = nx.read_gpickle("data.gpickle")
#print(G.edges(),"\n")
start = 19
goal = 20

def heuristic(a, b = 20):
   # Manhattan distance on a square grid
   a, b = G.node[a]['pts'][0], G.node[b]['pts'][0]
   return abs(a[1] - b[1]) + abs(a[0] - b[0])


frontier = PriorityQueue()
frontier.put(start, 0)
came_from = {}
cost_so_far = {}
came_from[start] = None
cost_so_far[start] = 0

while not frontier.empty():
   current = frontier.get()

   if current == goal:
      break
   
   for next in G.neighbors(current):
      new_cost = cost_so_far[current] + G[current][next]['weight']
      if next not in cost_so_far or new_cost < cost_so_far[next]:
         cost_so_far[next] = new_cost
         priority = new_cost + heuristic(goal, next)
         frontier.put(next, priority)
         came_from[next] = current

path = [20]
x = 20
while True:
    if came_from[x] == None:    break
    path.insert(0, came_from[x])
    x = came_from[x]

#for i in path:    print(i)

image = cv2.imread('dpixel.jpg')
plt.imshow(image, cmap = 'gray')
current = 0
while True:
    n = G.node[path[current]]['pts'][0]
    print(n[1], n[0])
    plt.plot(n[1], n[0], 'bo')
    if path[current] == 20:   break
    pt = G[path[current]][path[current + 1]]['pts']
    plt.plot(pt[:,1], pt[:,0], 'r')
    current = current + 1
plt.title('Shortest Path')
plt.show()

with open('path', 'wb') as fp:
    pickle.dump(path, fp)
