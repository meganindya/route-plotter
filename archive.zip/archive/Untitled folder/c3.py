import cv2
import numpy as np
import matplotlib.pyplot as plt

gr_sensitivity = 15;
gr_lb = np.array([60 - gr_sensitivity, 100, 50])
gr_ub = np.array([60 + gr_sensitivity, 255, 255])

rd_sensitivity = 15;
rd_lb = np.array([0, 50, 50])
rd_ub = np.array([10 + rd_sensitivity, 255, 255])

def coc(image, lb, ub):
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    mask = cv2.inRange(hsv, lb, ub)
    imge, contours, hier = cv2.findContours(mask.copy(), 1, 2)

    moments = [cv2.moments(cnt) for cnt in contours]
    centroids = [(int(M['m10'] / M['m00']), int(M['m01'] / M['m00'])) for M in moments]
    plt.imshow(image, 'gray')
    df = centroids[0]
    print(df[0], df[1])
    plt.plot(df, 'red')
    plt.show()
    #cv2.circle(mask, c, 3, (0, 0, 0))
    #cv2.imshow('img', mask)
    return centroids[0]

img = cv2.imread("tpixel.jpg")
img = cv2.resize(img, (400, 400), interpolation = cv2.INTER_AREA)
print(coc(img, gr_lb, gr_ub))
print(coc(img, rd_lb, rd_ub))

"""your = 4
left = (width - your)/2
top = (height - your)/2
right = (width + your)/2
bottom = (height + your)/2

im.crop((left, top, right, bottom)) #crop the center of the image

rgb = im.convert('RGB') # get three R G B values
r, g, b = rgb.getpixel((1, 1))

print(r,g,b)

image = cv2.imread('mask.png',0) # Black and white image

 contours, _, _ = cv2.findContours(image,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)

# Why only a row??
cnt = contours[1]

M = cv2.moments(cnt)
print M

cx = int(M['m10']/M['m00'])
cy = int(M['m01']/M['m00'])

print contours """
