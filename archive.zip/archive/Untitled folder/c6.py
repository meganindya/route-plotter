import matplotlib.image as mpimg
import matplotlib.pyplot as plt
import numpy as np
import cv2

def c_center(image, lb, ub):
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    mask = cv2.inRange(hsv, lb, ub)
    imge, contours, hier = cv2.findContours(mask.copy(), 1, 2)

    moments = [cv2.moments(cnt) for cnt in contours]
    centroids = [(int(M['m10'] / M['m00']), int(M['m01'] / M['m00'])) for M in moments]
    df = centroids[0]
    return df

b_lb = np.array([110,50,50])
b_ub = np.array([130,255,255])

y_lb = np.array([20, 100, 100])
y_ub = np.array([30, 255, 255])

img = cv2.imread('cpixel2.jpg')
db = c_center(img, b_lb, b_ub)
dy = c_center(img, y_lb, y_ub)

b,g,r = cv2.split(img)
img = cv2.merge([r,g,b])

plt.imshow(img, cmap = 'gray', interpolation = 'bicubic')
plt.plot(db[0], db[1], 'ko')
plt.plot(dy[0], dy[1], 'ko')
plt.show()
