import solidify2
import gen_graphCopy
import find_shortest_pathCopy
import guide_bot
import time

solidify2.main()
gen_graphCopy.main()
find_shortest_pathCopy.main()
guide_bot.main()
if 0xFF == ord('q'):    quit
