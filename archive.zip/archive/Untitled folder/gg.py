import matplotlib.pyplot as plt
import cv2
import numpy as np

def r2y(image):
    imgr = image
    #Convert BGR to HSV
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

    # define range of red color in HSV
    lower_red = np.array([0,50,50])
    upper_red = np.array([10,255,255])

    # Threshold the HSV image to get only blue colors
    mask = cv2.inRange(hsv, lower_red, upper_red)

    # Bitwise-AND mask and original image
    res = cv2.bitwise_and(image, image, mask = mask)
    image[mask == 255] = [0, 255, 255]

    titles = ['Original Image','Mask','Resultant','Final']
    images = [imgr, mask, res, image]

    for i in range(4):
        plt.subplot(2,2,i+1),plt.imshow(images[i],'gray')
        plt.title(titles[i])
        plt.xticks([]),plt.yticks([])

    plt.show()

img = cv2.imread("tpixel.jpg")
size = (400,400)
img = cv2.resize(img, size, interpolation = cv2.INTER_AREA)
r2y(img)
