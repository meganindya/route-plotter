import cv2
import numpy as np

src = cv2.imread("mask.jpg") # read input image
src = cv2.resize(src, (400, 400), interpolation = cv2.INTER_AREA)
gray = cv2.cvtColor(src, cv2.COLOR_BGR2GRAY) # convert to grayscale
blur = cv2.blur(gray, (3, 3)) # blur the image
ret, thresh = cv2.threshold(blur, 50, 255, cv2.THRESH_BINARY)
# Finding contours for the thresholded image
im2, contours, hierarchy = cv2.findContours(thresh, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

"""# create hull array for convex hull points
hull = []
 
# calculate points for each contour
for i in range(len(contours)):
    # creating convex hull object for each contour
    hull.append(cv2.convexHull(contours[i], False))"""

# create an empty black image
drawing = np.zeros((thresh.shape[0], thresh.shape[1], 3), np.uint8)

"""# draw contours and hull points
for i in range(len(contours)):
    color_contours = (0, 255, 0) # green - color for contours
    #color = (255, 0, 0) # blue - color for convex hull
    # draw ith contour
    cv2.drawContours(drawing, contours, i, color_contours, 1, 8, hierarchy)
    # draw ith convex hull object
    #cv2.drawContours(drawing, hull, i, color, 1, 8)"""
"""
cc = 0
for i in range(len(contours)):
    perimeter = cv2.arcLength(contours,True)
    if perimeter > cc:
        cc = perimeter
        cs = i

color_contours = (255, 0, 0)
cv2.drawContours(drawing, contours, cs, color_contours, 1, 8, hierarchy)"""
color_contours = (255, 0, 0)
mask = np.zeros(thresh.shape[:2], np.uint8)
cv2.drawContours(mask, contours, -1, color_contours, -1)
#cv2.drawContours(drawing, contours, -1, 255, -1)

cv2.imshow('sda',mask)
