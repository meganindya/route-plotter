import pickle
import math
from math import sqrt
import networkx as nx
import cv2
import numpy as np
import matplotlib.pyplot as plt
from skimage.util import invert
import os

    ##Functions
def n_node(n):
    return G.node[n]['pts'][0]

def dist(a, b):
    return sqrt((b[0] - a[0])**2 + (b[1] - a[1])**2)

def angle(a, b, c):
    m1 = slope(a, b)
    m2 = slope(b, c)
    a1 = math.degrees(math.atan((m2 - m1) / (1 + (m1 * m2))))
    return a1
    
def slope(a, b):
    if (b[1] - a[1]) == 0:  return 2**500
    else:   return (b[0] - a[0]) / (b[1] - a[1])

def path_red(path, i = 0):
    path_r = path.copy()
    while True:
        if i == (len(path_r) - 2):    break
        if path_r[i] == -1:     i = i + 1; continue
        x = i + 1
        while True:
            if path_r[x] == 20:   break
            ang = abs(angle(n_node(path_r[i]), n_node(path_r[x]), n_node(path_r[x + 1])))
            if ang > 2:   break
            path_r[x] = -1; x = x + 1
        i = i + 1
    return list(filter(lambda a: a != -1, path_r))

def draw_map(img, path, path_r, db, dy):
    plt.imshow(img, cmap = 'gray')
    for x in path_r:
        plt.plot(n_node(x)[1], n_node(x)[0], 'go')
    current = 0
    while True:
        if path[current] == 20:   break
        pt = G[path[current]][path[current + 1]]['pts']
        plt.plot(pt[:,1], pt[:,0], 'r')
        current = current + 1
    plt.title('Shortest Path')
    plt.plot(db[0], db[1], 'ko')
    plt.plot(dy[0], dy[1], 'ko')
    #fig.savefig('path.jpg')
    #plt.show()

def c_center(image, lb, ub):
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    mask = cv2.inRange(hsv, lb, ub)
    imge, contours, hier = cv2.findContours(mask.copy(), 1, 2)

    moments = [cv2.moments(cnt) for cnt in contours]
    centroids = [(int(M['m10'] / M['m00']), int(M['m01'] / M['m00'])) for M in moments]
    df = centroids[0]
    return df

def load_images(folder):
    images = []
    for filename in os.listdir(folder):
        img = cv2.imread(os.path.join(folder,filename))
        if img is not None:
            images.append(img)
    return images




    ##Statements
img = cv2.imread('dpixel2.jpg')
with open('path', 'rb') as fp:
    path = pickle.load(fp)
G = nx.read_gpickle("data.gpickle")
ims = load_images('dtest')

path_r = path_red(path)

b_lb = np.array([110,50,50])
b_ub = np.array([130,255,255])

y_lb = np.array([20, 100, 100])
y_ub = np.array([30, 255, 255])


for i in ims:
    db = c_center(i, b_lb, b_ub)
    dy = c_center(i, y_lb, y_ub)
    db = [db[1], db[0]]
    dy = [dy[1], dy[0]]

    b,g,r = cv2.split(img)
    img = cv2.merge([r,g,b])
    draw_map(invert(img), path, path_r, db, dy)

    b_dir = slope(dy, db)
    b_dir = 'inf' if (b_dir > 2**50) else b_dir
    print(db, dy, n_node(19))
    if dist(dy, n_node(19)) < dist(db, n_node(19)):
        ang = 0 - angle(db, dy, n_node(19)) - 180
    else:
        ang = angle(n_node(19), dy, db)
    if abs(ang) > 180:  ang = ang % 180
    print(b_dir)
    print(ang)
    x = db[1] + dy[1]
    y = db[0] + dy[0]
    while abs(ang) > 1:
        an = abs(ang * 2)/ang
        print(math.cos(math.radians(an)))
        db[1] = x + (db[1] - x) * math.cos(math.radians(an)) - (db[0] - y) * math.sin(math.radians(an))
        db[0] = y + (db[1] - x) * math.sin(math.radians(an)) + (db[0] - y) * math.cos(math.radians(an))
        dy[1] = x + (dy[1] - x) * math.cos(math.radians(an)) - (dy[0] - y) * math.sin(math.radians(an))
        dy[0] = y + (dy[1] - x) * math.sin(math.radians(an)) + (dy[0] - y) * math.cos(math.radians(an))
        print([db[1], db[0]], [dy[1], dy[0]])
        #ang = ang - 1 if ang > 0 else ang + 1
        ang = 0
        print(ang)
    print("\n")
