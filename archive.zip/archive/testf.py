import cv2
import numpy as np
import matplotlib.pyplot as plt
import networkx as nx
from PIL import Image
from skimage.morphology import skeletonize
from skimage.util import invert
import sknw

def r2y(image):
    #Convert BGR to HSV
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

    #define range of red color in HSV
    lower_red = np.array([0,50,50])
    upper_red = np.array([10,255,255])

    #Threshold the HSV image to get only red colors
    mask = cv2.inRange(hsv, lower_red, upper_red)

    #Change color at masked region to cyan 
    image[mask == 255] = [255,255,0]
    cv2.imshow('new',image)
    return image

img = cv2.imread("C:/Users/Anindya/Desktop/tpixel.jpg")
img = cv2.resize(img, (400, 400), interpolation = cv2.INTER_AREA)
cv2.imshow('org',img)

img = r2y(img)
img = invert(img)
cv2.imshow('inv',img)

#kernel = np.ones((1,1),np.uint8)

    #Convert to GrayScaledImage
grayscaled = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)

    #BınaryThreshold + OtsuThreshold + BinaryThreshold
retval, threshold = cv2.threshold(grayscaled, 10, 255, cv2.THRESH_BINARY_INV+cv2.THRESH_OTSU)
retval, threshold2 = cv2.threshold(threshold, 10, 255, cv2.THRESH_BINARY_INV)
threshold2[threshold2 == 255] = 1

    #Skeletonize the Thresholded Image
skel = skeletonize(threshold2)

    #Build Graph from skeleton
graph = sknw.build_sknw(skel, multi=False)
G = nx.Graph(graph)
plt.imshow(img, cmap='gray')

    #Draw Edges by 'pts'
for (s,e) in graph.edges():
    ps = graph[s][e]['pts']
    plt.plot(ps[:,1], ps[:,0], 'red')

    #Draw Node by 'o'   
node, nodes = graph.node, graph.nodes()
ps = np.array([node[i]['o'] for i in nodes])
plt.plot(ps[:,1], ps[:,0], 'g.')
plt.title('Skeletonize')
#plt.savefig('Overlay_Maze.jpg')
plt.show()

G = nx.path_graph(len(ps))
G = nx.karate_club_graph()
pos = nx.spring_layout(G)
nx.draw(G,pos,node_color='b')
